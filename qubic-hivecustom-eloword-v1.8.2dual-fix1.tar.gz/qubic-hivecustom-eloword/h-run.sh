#!/bin/bash

# Chemin vers les répertoires des instances CPU et GPU
EXECUTABLE="./eloword"

echo $(date +%s) > "/tmp/miner_start_time"

echo $MINER_LOG_BASENAME.log

echo "Starting qli-Client instances..."
"$EXECUTABLE"
